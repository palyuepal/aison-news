import {ImageResponse} from 'next/og';

export const alt='NutriFact Lab — 營養，唔好靠估。';
export const size={width:1200,height:630};
export const contentType='image/png';

export default function Image(){
  return new ImageResponse(
    <div style={{width:'100%',height:'100%',display:'flex',flexDirection:'column',justifyContent:'space-between',padding:'70px 78px',background:'#f4f5ee',color:'#0c2a24',fontFamily:'Arial, sans-serif'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div style={{display:'flex',alignItems:'center',gap:22}}>
          <div style={{width:92,height:92,borderRadius:24,display:'flex',alignItems:'center',justifyContent:'center',background:'#0c2a24',color:'#f7f8f2',fontSize:38,fontWeight:800}}>NF</div>
          <div style={{display:'flex',flexDirection:'column'}}>
            <div style={{fontSize:42,fontWeight:800}}>NutriFact Lab</div>
            <div style={{fontSize:18,letterSpacing:4,marginTop:7}}>NUTRITION · EVIDENCE</div>
          </div>
        </div>
        <div style={{width:34,height:34,borderRadius:99,background:'#c8ff3d'}} />
      </div>
      <div style={{display:'flex',flexDirection:'column',maxWidth:920}}>
        <div style={{fontSize:86,lineHeight:1.03,fontWeight:900,letterSpacing:-4}}>營養，唔好靠估。</div>
        <div style={{fontSize:31,lineHeight:1.45,marginTop:28}}>30 個核心成分 · 10 個深度指南 · Outcome-specific evidence · Safety · Sources</div>
      </div>
      <div style={{display:'flex',justifyContent:'space-between',fontSize:20}}>
        <div>香港繁中 · Evidence-based nutrition</div>
        <div style={{fontWeight:700}}>nutrifactlab.com</div>
      </div>
    </div>,
    size
  );
}
