export const metadata={title:'Launch Status',description:'NutriFact Lab 公開 launch checklist：domain、Search Console、Analytics、privacy、reviewer 與聯絡渠道狀態。',alternates:{canonical:'/launch-status'}};
const rows=[
['Next.js production','ready','Next.js 16.3.3；內容以 Static / SSG 預先生成'],
['SEO / sitemap / robots','ready','Canonical、Open Graph、Article schema、sitemap、robots 已落地'],
['Trust layer','ready','Byline、review status、Editorial Policy、Corrections、Disclosures 已上線'],
['Privacy page','ready','已公開資料處理與 Analytics consent 原則'],
['Brand metadata','ready','Favicon、Apple icon、Web App Manifest、Open Graph / Twitter 分享圖已落地'],
['Custom domain','pending','nutrifactlab.com 尚未購買／連接'],
['Official email','pending','待 custom domain 啟用後建立 editorial / corrections 收件渠道'],
['Google Search Console','ready-config','網站已預留 verification token；仍需 Google 產生實際 token'],
['Analytics','ready-config','Consent-ready；仍需建立 GA4 property / Measurement ID 才會真正追蹤'],
['External professional review','pending','大部分健康內容尚未有具名外部臨床／營養專業 reviewer']
];
export default function Page(){return <section className="detailHero trustPage"><div className="wrap narrow"><span className="kicker">v0.9 · PUBLIC LAUNCH</span><h1 className="guideTitle">公開邊啲已完成，邊啲未完成。</h1><p>Launch checklist 唔用綠燈掩飾未做完嘅部分。涉及 domain、第三方帳戶同真人專業審核嘅項目會保持 pending。</p></div><div className="wrap narrow section trustCopy"><div className="statusList">{rows.map(([name,status,note])=><div className={'launchStatus '+status} key={name}><b>{name}</b><span>{note}</span><em>{status==='ready'?'READY':status==='ready-config'?'READY FOR CONFIG':'PENDING'}</em></div>)}</div><div className="warning">Search Console 驗證 token 同 GA4 Measurement ID 都係帳戶專屬值；網站已準備好接口，但唔應自行捏造。</div></div></section>}
